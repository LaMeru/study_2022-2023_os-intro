## [1.2.3](https://github.com/LaMeru/Test_repo/compare/v1.0.0...v1.2.3) (2024-03-07)



# 1.0.0 (2024-03-07)


### Features

* **readme.md:** first commit ([882cf76](https://github.com/LaMeru/Test_repo/commit/882cf7689792299f0eb1ce17b138531db7b2b2b7))



