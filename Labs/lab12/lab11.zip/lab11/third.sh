#!/usr/bin/env bash
echo "Введите путь к каталогу или папке"
read ctlg
change = $ctlg
cd $change
echo *
